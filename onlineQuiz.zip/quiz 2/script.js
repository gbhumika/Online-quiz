var title, subToday=[], pos=0, rand=[], ran, choice, textanswer, score=0, count, cquestion=0, wquestion=0, width=0;
function selectSub()
{
				var d = new Date();
				sub= d.getDate()%4;
				switch(sub){
				case 0:
				subToday=htmlq;
				title="HTML";
				break;
				case 1:
				subToday=jsq;
			  title="Java Script";
				break;
				case 2:
				subToday=his;
				title="History";
				break;
				case 3:
				subToday=math;
				title="Mathematics";
				break;
				default:
				subToday=math;
				title="Mathematics";
				}
				setTitle();
}
function setTitle()
{
document.getElementById('ti').innerHTML ="Today's topic is "+title;
}
function onstart()
{
	count=0;
	score=0;
	pos=0;
	cquestion=0;
	wquestion=0;
	width=0;
	var elem = document.getElementById("myProgress");
	elem.style.width = 100 + '%';
	document.getElementById("score").style.visibility="visible";
	document.getElementById("watch").style.visibility="visible";
askques();
}
function _(x){return document.getElementById(x);}
function generateRandomNum()
{
			ran= Math.floor((Math.random() *10));
			alert(ran);
			for (i=0;i<10;i++)
			{
					if (ran == rand[i])
					{
					generateRandomNum();
					}

			}
			rand.push(ran);
}

function askques()
{
			currentscore();
			pos++;
			if(pos > subToday.length)
					{
						showscore();
					}
					else
					{
						move();
						countDownStart();
						generateRandomNum();
						ques=subToday[ran].question;
						q.innerHTML="<h3>"+ques+"</h3>";
						if (subToday[ran].questionType == 1)
										{
										showChoice();

										}
						else
									{
										showText();
									}
					}
}

function showChoice()
{
	q= _("q");
	a=subToday[ran].choices[0];
	b=subToday[ran].choices[1];
	c=subToday[ran].choices[2];
	q.innerHTML+="<input type='radio'name='choices' value='A'> "+a+"<br>";
	q.innerHTML+="<input type='radio'name='choices' value='B'> "+b+"<br>";
	q.innerHTML+="<input type='radio'name='choices' value='C'> "+c+"<br><br>";
}

function showText()
{
	q= _("q");
	q.innerHTML+="<input name='answer' required size=40px/>";
}

function checkAnswer()
{
	 if  (subToday[ran].questionType == 1)
				{
				choice = document.getElementsByName("choices");
				for (var i = 0; i < 3; i++)
							{
								if (choice[i].checked)
								{
										var y=1;
										if(subToday[ran].choices[i]==subToday[ran].correctChoice)
										{
											score = score + 5;
											cquestion=cquestion + 1;
										}
								 else
								 		{
										wquestion=wquestion + 1;
										}
								}
							}
					if(!y)
								alert("please select a choice");
					else
							 {
								countDownClear();
								askques();
							 }
			}

	else if  (subToday[ran].questionType == 2)
			{
				textanswer = document.getElementsByName("answer").value;
				// var textanswer1=textanswer.toUpperCase();
				if( textanswer == subToday[ran].correctChoice)
				{
					score = score + 10;
					cquestion=cquestion + 1;
				}
				else
				{
					wquestion=wquestion + 1;
				}
				countDownClear();
				askques();
			}
}

function showscore()
{
	q= _("q");
	q.innerHTML="<h1>Your Score is "+score+"</h1><p style='color:blue'>correct: "+cquestion+"<p style='color:red'>incorrect: "+wquestion;
	document.getElementById("score").style.visibility="hidden";
	document.getElementById("watch").style.visibility="hidden";
}

function countDownStart()
{
 	count = 30;
	countDownNow();
}

function countDownNow()
{
	--count;
		_("watch").innerHTML="<h4>Remaining Time: "+count+"<h4>";
	if(count > 0)
		{
		ctimer=setTimeout(countDownNow, 1000);
		}

	if(count==0) /*If you have not answered a question in the given time frame */
			{
				askques();
			}
}

function countDownClear() /* This function clears the timer for every function */
		{
			clearTimeout(ctimer);
		}

function currentscore()
	{
	_("score").innerHTML="<p style='color:blue'>correct: "+cquestion+"<p style='color:red'>wrong: "+wquestion;
  }

function move()
{
	var elem = document.getElementById("myBar");
	width = width+10;
  elem.style.width = width + '%';
}

window.addEventListener("load", selectSub, false);
